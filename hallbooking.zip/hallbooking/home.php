 <?php
 session_start();
if(!isset($_SESSION['email'])){
   header('location:login.php?sessionfailed');
}
include_once 'serverside/databaseconnect.php';
 $email=$_SESSION['email'];
 $sql="SELECT * from employee WHERE email='$email'";
 $result=mysqli_query($conn,$sql);
  if (mysqli_num_rows($result) < 1) {
    header('location:logout.php?sessionfailed');
   exit();
}
?>
<!DOCTYPE html>
		<html lang="en" >
		<head>
		  <meta charset=utf-8 />
		  <meta name="viewport" content="width=device-width,height=device-height initial-scale=1.0,maximum-scale=1.0,user-scalable=0">
		  <title>Room Booking - Home Page</title>
		  <link rel="stylesheet" href="https://code.getmdl.io/1.1.3/material.orange-indigo.min.css">
		  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		   <link rel="stylesheet" href="css/homestyle.css">
		   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
		   <!--<script defer src="https://code.getmdl.io/1.1.3/material.min.js"></script>-->
		   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		   <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
		   <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.20.1/locale/af.js"></script>
		    <script  src="homeapp.js"></script>
		</head>
		<body class="blue">
		<header>
		    <div class="navbar-fixed">
		    <nav class="yellow" role="navigation">
		        <div class="nav-wrapper container">
		            <a id="logo-container" href="#splash" class="brand-logo center-block">
		                <div class="logo center-block"><img src="images/logo.png" style="padding:10px;" width="200px"/></div>
		            </a>
		            <ul class="right hide-on-med-and-down">
		                 <li> <button class="mdl-button mdl-js-button mdl-button--raised  white right" style="margin:10px;">About</button></li>
		                 <li> <button class="mdl-button mdl-js-button mdl-button--raised  white right" style="margin:10px;" onclick="window.location.href='cancelrequest.php'">Cancel Requests</button></li>
		                <li><button class="mdl-button mdl-js-button mdl-button--raised  white right" id="quickstart-sign-in" onclick="window.location.href='logout.php'" name="signin" style="margin:10px;">Sign Out</button></li>
		            </ul>
		            <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
		        </div>
		    </nav>
		</div>
		<ul id="nav-mobile" class="side-nav">
		  <li> <button class="mdl-button mdl-js-button white" style="width:100%;">About</button></li>
		  <li> <button class="mdl-button mdl-js-button white" style="width:100%;" onclick="window.location.href='cancelrequest.php'">Cancel Requests</button></li>
		  <li><button class="mdl-button mdl-js-button white" id="quickstart-sign-in1" name="signin" onclick="window.location.href='logout.php'" style="width:100%;">Sign Out</button></li>
		  
		</ul>
		</header>
<!-- <body class="blue"> -->
		<br>
		     <section class="cal">
	       <div class="content">
	    <div class="calendar-container">
	      <div class="calendar"> 
	        <div class="year-header"> 
	          <span class="left-button" id="prev"> &lang; </span> 
	          <span class="year" id="label"></span> 
	          <span class="right-button" id="next"> &rang; </span>
	        </div> 
	        <table class="months-table"> 
	          <tbody>
	            <tr class="months-row">
	              <td class="month">Jan</td> 
	              <td class="month">Feb</td> 
	              <td class="month">Mar</td> 
	              <td class="month">Apr</td> 
	              <td class="month">May</td> 
	              <td class="month">Jun</td> 
	              <td class="month">Jul</td>
	              <td class="month">Aug</td> 
	              <td class="month">Sep</td> 
	              <td class="month">Oct</td>          
	              <td class="month">Nov</td>
	              <td class="month">Dec</td>
	            </tr>
	          </tbody>
	        </table> 
	        
	        <table class="days-table"> 
	          <td class="day">Sun</td> 
	          <td class="day">Mon</td> 
	          <td class="day">Tue</td> 
	          <td class="day">Wed</td> 
	          <td class="day">Thu</td> 
	          <td class="day">Fri</td> 
	          <td class="day">Sat</td>
	        </table> 
	        <div class="frame"> 
	          <table class="dates-table"> 
	              <tbody class="tbody">             
	              </tbody> 
	          </table>
	        </div> 
	        <br><br>
	        <button class="button" id="add-button">Add Event</button>
	      </div>
	    </div>
	    <div class="events-container">
	    </div>
	    <div class="dialog" id="dialog">
	        <form class="form white" id="form">
	          <div class="form-container white" align="center">
	          <!--   <label class="form-label" id="valueFromMyButton" for="teachname">Booked By: (Format= Name,Designation,Department)</label>
	            <input class="input" type="text" id="book" maxlength="72"> -->
	            <label class="form-label" id="valueFromMyButton" for="name">Event Name</label>
	            <input required class="input" type="text" id="name" maxlength="36">
	            <label class="form-label" id="valueFromMyButton" for="hall">Select a Hall</label>
	              <div class="input-field col s12">
	              <select required name="hall" id="hall">
	                   <option value="" disabled selected>Select a Hall</option>
	                   <option value="Amriteshwari Hall">Amriteshwari Hall-Max. Capacity-XX</option>
	                   <option value="Sudhamani Hall">Sudhamani Hall-Max. Capacity-XX</option>
	                   <option value="Krishna Hall">Krishna Hall-Max. Capacity-XX</option>
	                   <option value="Rama Hall">Rama Hall-Max. Capacity-XX</option>
	                   <option value="Valmiki Hall">Valmiki Hall-Max. Capacity-XX</option>
	                   <option value="Computer Lab1">Computer Lab1-Max. Capacity-XX</option>
	                   <option value="Computer Lab2">Computer Lab2-Max. Capacity-XX</option>
	                   <option value="Computer Lab3">Computer Lab3-Max. Capacity-XX</option>
	                   <option value="Computer Lab4">Computer Lab4-Max. Capacity-XX</option>
	                   <option value="E-Learning Lab">E-Learning Lab-Max. Capacity-XX</option>
	                   <option value="A Block Ground Floor Seminar Hall">A Block Ground Floor Seminar Hall-Max.Capacity-XX</option>
	                   <option value="Seminar Hall AD Office">Seminar Hall Near AD Office-Max. Capacity-XX</option>
	             </select>
	             </div>
	            <label class="form-label" id="valueFromMyButton" for="starttime1">Pick Start Time</label>
	            <div class="row">
	            	<div class="input-field col s6 m6">
	              <select required name="starthour" id="starttime1">
	                   <option value="" disabled selected>Hours</option>
	                   <option value="8">8 A.M</option>
	                   <option value="9">9 A.M</option>
	                   <option value="10">10 A.M</option>
	                   <option value="11">11 A.M</option>
	                   <option value="12">12 P.M</option>
	                   <option value="1">1 P.M</option>
	                   <option value="2">2 P.M</option>
	                   <option value="3">3 P.M</option>
	                   <option value="4">4 P.M</option>
	             </select>
	         </div>
	         <div class="input-field col s6 m6">
	             <select required name="startmin" id="starttime2">
	                   <option value="" disabled selected>Minutes</option>
	                   <option value="1">00</option>
	                   <option value="2">30</option>
	             </select>
	         </div>
	     </div>
	     <label class="form-label" id="valueFromMyButton" for="endtime1">Pick End Time</label>
	            <div class="row">
	            	<div class="input-field col s6 m6">
	              <select required name="endhour" id="endtime1">
	                   <option value="" disabled selected>Hours</option>
	                   <option value="8">8 A.M</option>
	                   <option value="9">9 A.M</option>
	                   <option value="10">10 A.M</option>
	                   <option value="11">11 A.M</option>
	                   <option value="12">12 P.M</option>
	                   <option value="1">1 P.M</option>
	                   <option value="2">2 P.M</option>
	                   <option value="3">3 P.M</option>
	                   <option value="4">4 P.M</option>
	             </select>
	         </div>
	         <div class="input-field col s6 m6">
	             <select required name="endmin" id="endtime2">
	                   <option value="" disabled selected>Minutes</option>
	                   <option value="1">00</option>
	                   <option value="2">30</option>
	             </select>
	         </div>
	     </div>

	     <label class="form-label" id="valueFromMyButton" for="description">Logistical Requirements</label>
          <div class="row">
          <div class="input-field col s12">
            <textarea required name="decription" id="textarea1" class="materialize-textarea" placeholder="List the things required for the event Eg: (Mike, Projector, Internet etc)" data-length="60"></textarea>
          </div>
      </div>
        <label class="form-label" id="valueFromMyButton" for="targeted1">Targeted Audience,Host Club,Speaker/Guest(If Any)</label>
        <div class="row">
          <div class="input-field col s12">
            <textarea id="textarea2" required name="targeted" class="materialize-textarea" placeholder="Targeted Audience: CSE 1st Years.Host Club:FACE.Speaker:None" data-length="120"></textarea>
          </div>
        </div>

                <input type="button" value="Cancel" class="button" id="cancel-button">
	            <input type="button" value="OK" class="button" id="ok-button">
        </div>
      </form>
    </div>
      </div>
<!-- 	          </div> -->
	  <!--     </div> -->
	       <!-- </div> -->
	     </section>
	</body>
		</html>