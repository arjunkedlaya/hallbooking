<?php
session_start();
?> 
  <!DOCTYPE html>
    <html lang="en" >
    <head>
      <meta charset=utf-8 />
      <meta name="viewport" content="width=device-width,height=device-height initial-scale=1.0,maximum-scale=1.0,user-scalable=0">
      <title>Login Page - Hall Booking</title>
       <link rel="stylesheet" href="css/loginstyle.css">
       <link rel="stylesheet" href="https://code.getmdl.io/1.1.3/material.orange-indigo.min.css">
      <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
     <!--  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css"> -->
       <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
       <!--<script defer src="https://code.getmdl.io/1.1.3/material.min.js"></script>-->
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
    </head>