	var upcomingEvents = document.getElementById("upcomingEvents");
	var eventHolder = document.getElementById("eventHolder");
	var removeEvent = document.getElementById("removeEvent");
	const months = [ 
	    "Jan", 
	    "Feb", 
	    "Mar", 
	    "Apr", 
	    "May", 
	    "Jun", 
	    "Jul", 
	    "Aug", 
	    "Sep", 
	    "Oct", 
	    "Nov", 
	    "Dec" 
	];
		    var a=[],i=0;
	$(document).ready(function() 
	{   $('.button-collapse').sideNav();
	    $('.parallax').parallax();
	    $('.collapsible').collapsible();
	    $('.dropdown-trigger').dropdown();
	     $.ajax({
         url: 'serverside/supercancelconfirm.php',
         async:false,
         success: function(data) {
         a=data;
         }
        });
	    var c=0;i=0;
	    a=JSON.parse(a);
	    Object.keys(a).forEach(function(key) {
	    var event=a[key];
	    var m=parseInt(event['date'].slice(-2))+"/"+parseInt(event['date'].substr(5,7))+"/"+parseInt(event['date'].substr(0,4));
        var d=new Date(parseInt(event['date'].substr(0,4)),parseInt(event['date'].substr(5,7))-1,parseInt(event['date'].slice(-2)));
	    var today=new Date();
	    var temp=event["ename"]+","+event["desig"]+","+event["dname"];
	    var em=parseInt(event['ftime'].substr(0,event['ftime'].indexOf(':')));
	    var rm=parseInt(event['ttime'].substr(0,event['ttime'].indexOf(':')));
	    if(em==12||em<=7)
        {
        event["ftime"]=event["ftime"]+" P.M";
        }
        else
         event["ftime"]=event["ftime"]+" A.M";
        if(rm==12||rm<8)
        {
        event["ttime"]=event["ttime"]+" P.M";
        }
       else
        event["ttime"]=event["ttime"]+" A.M";
        a[key]=event;
        a[key]["bookedby"]=temp;
        a[key]["day"]=m;
	    if(event["cancelreq"]=="NO"&&d>=today){
	    var x=document.getElementById("upcomingEvents");c=1;
	    var j='<li id="eventHolder" class="e'+i+'"><div class="event-date-holder"><span id="dateNumber">'+parseInt(event['date'].slice(-2))+'</span><span id="dateDay">'+months[parseInt(event['date'].substr(5,7))-1]+'</span></div><div class="event-details-holder"><h1>'+event["eventname"]+"<br>"+event["hall"]+'</h1><p id="eventDescription">'+'Time : '+event["ftime"]+"-"+event["ttime"]+"<br>Booked By : "+temp+"<br>Status : "+event["status"]+'<br>Logistic Requirements:'+event["description"]+'<br>Targeted Audience:'+event["target"]+'</p><ul id="editTools"><li><button onClick="hello('+i+')"><i class="material-icons" id="removeEvent" style="color:red;">close</i></button></li></ul></div></li>';
	     x.innerHTML+=j;
	    }
	    i++;
	    });
	    if(c!=1){
	       var x=document.getElementById("noevent");
	       x.innerHTML="No event requests currently";
	     }
	});
	// Delete icon removed event from list
	function hello(i){
	 var j=".e"+i;
	 $(j).hide();
	 console.log(a[i]);
	  $.ajax({
            type : "POST",  //type of method
            url  : "serverside/cancelled.php",  //your page
            data : {  
            r_id:a[i]["r_id"],
            time:a[i]["ftime"]+"-"+a[i]["ttime"],
            bookedby:a[i]["bookedby"],
            day:a[i]["day"]
            },// passing the values
            success: function(res){  
                            console.log(hello);        //do what you want here...
                    }
        });  
	}
	// function confirm(i){
	//     var j=".e"+i;
	//     $(j).hide();
	//     const dbRefObject=firebase.database().ref().child('events');
	//     dbRefObject.on('value',snap => {
	//     var t=snap.val();
	//     a=t;
	//     Object.keys(a).forEach(function(key) {
	//     event=a[key];
	//     i--;
	//     if(i==0){
	//         var newevent={
	//         "occasion": event["occasion"],
	//         "year":  event["year"],
	//         "month": event["month"],
	//         "day": event["day"],
	//         "from":event["from"],
	//         "till":event["till"],
	//         "hall":event["hall"],
	//         "status":"Confirmed by AD and Dept.HOD",
	//         "bookedby":event["bookedby"]
	//         }
	//         dbRefObject.child(key).set(newevent);
	//     }
	//     });
	//     }); 
	// }
	//<li><button onClick="confirm('+i+')"><i class="material-icons" id="addEvent" style="color:green;">done</i></button></li>