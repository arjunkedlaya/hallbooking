<?php
 session_start();
 if(!isset($_SESSION['email'])){
   header('location:login.php?sessionfailed');
   exit();
}
 include_once 'databaseconnect.php';
 $rid=$_POST['r_id'];
 $sql ="UPDATE request SET cancelreq='NO',status='Confirmed' WHERE r_id='$rid'";
 mysqli_query($conn,$sql);
 //AND a.e_id=b.e_id AND b.d_id=c.d_id AND c.s_id = d.s_id AND d.s_id='$super'
 //FROM request a,employee b,department c,supervisor b
 //  AND a.e_id=b.e_id AND b.d_id=c.d_id AND c.s_id = d.s_id AND d.s_id='$super'