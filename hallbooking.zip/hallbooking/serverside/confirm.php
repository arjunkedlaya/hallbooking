<?php
 // require("/htdocs/hallbooking/serverside/PHPMailer-master/src/PHPMailer.php");
 //  require("/htdocs/hallbooking/serverside/PHPMailer-master/src/SMTP.php");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

 session_start();
 if(!isset($_SESSION['email'])){
   header('location:login.php?sessionfailed');
   exit();
}
 include_once 'databaseconnect.php';
 $rid=$_POST['r_id'];
 $day=$_POST['day'];
 $time=$_POST['time'];
 $bookedby=$_POST['bookedby'];
 $sql ="UPDATE request SET cancelreq='NO',status='Confirmed' WHERE r_id='$rid'";
 mysqli_query($conn,$sql);
 $sql="SELECT a.email,b.hall,b.eventname,b.status,b.description,b.date FROM employee a,request b WHERE b.r_id='$rid' and b.e_id=a.e_id";
 $result=mysqli_query($conn,$sql);
 $row=array();
 if (mysqli_num_rows($result) == 1) {
    // output data of each row
    $row = mysqli_fetch_assoc($result);
        // echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
 }
$hall=$row['hall'];
$eventname=$row['eventname'];
$recep='arjunskedlaya1@gmail.com';
$message = '<html><body>';
$message .= '<h1 style="color:green;">Amrita Hall Booking Confirmation Intimation</h1>';
$message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
$message .= "<tr style='background: #eee;'><td><strong>Event Name:</strong> </td><td>" . $eventname . "</td></tr>";
$message .= "<tr style='background: #eee;'><td><strong>Booked By:</strong> </td><td>" . $bookedby . "</td></tr>";
$message .= "<tr><td><strong>Hall:</strong> </td><td>" . strip_tags($hall) . "</td></tr>";
$message .= "<tr><td><strong>Event Requirements:</strong> </td><td>" . strip_tags($row['description']) . "</td></tr>";
$message .= "<tr><td><strong>Date:</strong> </td><td>" . strip_tags($day) . "</td></tr>";
$message .= "<tr><td><strong>Time:</strong> </td><td>" . strip_tags($time) . "</td></tr>";
$message .= "<tr><td><strong>Status:</strong> </td><td>" . strip_tags($row['status']) . "</td></tr>";
$message .= "</table>";
$message .= "</body></html>";
$mail = new PHPMailer;
$mail->SMTPOptions = array(
   'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
); // create a new object

$fp = fsockopen('tcp://smtp.gmail.com', 587, $errno, $errstr, 10);
echo fgets($fp, 128);
fclose($fp);

$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 4; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
$mail->SMTPSecure = 'tls'; // secure transfer enabled REQUIRED for Gmail
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587; // or 587
$mail->IsHTML(true);
$mail->Username = "maiyellapogaru@gmail.com";
$mail->Password = "[pogaru1]";
$mail->SetFrom('no-reply@amrita.com');
$mail->Subject = "ALERT : {$hall} Booking Request Confirmed for {$eventname} on {$day}";
//$mail->Body = "<b>Event Details</b><br>Event Name:{$eventname}<br>Date:{$date}<br>Status:{$row['status']}";
$mail->Body = "{$message}";
$mail->AddAddress("{$recep}");

 if(!$mail->Send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
 } else {
    echo "Message has been sent";
 }
 //AND a.e_id=b.e_id AND b.d_id=c.d_id AND c.s_id = d.s_id AND d.s_id='$super'
 //FROM request a,employee b,department c,supervisor b
 //  AND a.e_id=b.e_id AND b.d_id=c.d_id AND c.s_id = d.s_id AND d.s_id='$super'