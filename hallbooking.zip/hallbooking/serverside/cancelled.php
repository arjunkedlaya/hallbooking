<?php
 session_start();
 if(!isset($_SESSION['email'])){
   header('location:login.php?sessionfailed');
   exit();
}
 include_once 'databaseconnect.php';
 $email=$_SESSION['email'];
 $rid=$_POST['r_id'];
 include_once 'databaseconnect.php';
 $sql ="UPDATE request SET cancelreq='YES',status='Cancelled' WHERE r_id='$rid'";
 mysqli_query($conn,$sql);
//   if (mysqli_query($conn, $sql)) {
//     echo "Record updated successfully";
// } else {
//     echo "Error updating record: " . mysqli_error($conn);
// }
