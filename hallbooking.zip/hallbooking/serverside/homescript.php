<?php
  session_start();
  $eventname=$_POST['occasion'];
  $hall=$_POST['hall'];
  $status=$_POST['status'];
  $desc=$_POST['description'];
  $date=$_POST['date'];
  $from=$_POST['from'];
  $till=$_POST['till'];
  $email=$_SESSION['email'];
  $target=$_POST['target'];
  if(isset($_SESSION['email']))
  {   
  include_once 'databaseconnect.php';
  $sql="SELECT e_id FROM employee WHERE email ='$email'";
  $result=mysqli_query($conn,$sql);
  $row=mysqli_fetch_assoc($result);
  $eid=$row['e_id'];
  }
  if(!isset($_SESSION['email'])){
   header('location:login.php?sessionfailed');
   exit();
  }
  $sql="INSERT INTO request (hall,ftime,ttime,description,date,e_id,eventname,status,target) VALUES ('$hall', '$from', '$till', '$desc','$date','$eid','$eventname','$status','$target');";
  mysqli_query($conn, $sql);
  header("Location:../home.php?request=success");
  exit();
  // con.connect(function(err) {
  // if (err) throw err;
  // console.log("Connected!");
  // var sql = "INSERT INTO customers (name, address) VALUES ('Company Inc', 'Highway 37')";
  // con.query(sql, function (err, result) {
  //   if (err) throw err;
  //   console.log("1 record inserted");
  //     });
  //    });

   // var data = {
    //     occasion: name,
    //     year: date.getFullYear(),
    //     month: date.getMonth()+1,
    //     day: day,
    //     from:fromtime,
    //     till:tilltime,
    //     hall:hall,
    //     status:"Pending",
    //     description:desc
    // };