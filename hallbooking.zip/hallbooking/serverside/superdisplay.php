<?php
 session_start();
 if(!isset($_SESSION['email'])){
   header('location:../login.php?sessionfailed');
   exit();
}
 include_once 'databaseconnect.php';
 $email=$_SESSION['email'];
 $sql="SELECT s_id from supervisor WHERE supemail='$email'";
 $result=mysqli_query($conn,$sql);
  if (mysqli_num_rows($result) > 0) {
  	$row = mysqli_fetch_assoc($result);
 	    // output data of each row
        // echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
    $sup=$row['s_id'];
}
else
{
   header('location:../logout.php?sessionfailed');
   exit();
}
 $rows=array();
 $sql="SELECT a.r_id,a.hall,a.ftime,a.ttime,a.description,a.date,a.cancelreq,a.eventname,a.status,a.description,a.target,b.ename,b.desig,c.dname FROM request a,supervisor d,department c,employee b WHERE a.e_id=b.e_id AND b.d_id=c.d_id AND c.s_id=d.s_id AND d.s_id=$sup"; 
 $result=mysqli_query($conn,$sql);
 if (mysqli_num_rows($result) > 0) {
 	
    // output data of each row
    $rows = array();
    while($row = mysqli_fetch_assoc($result)) {
        // echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
        $rows[] = $row;
    }
}
else
{
	 $rows = array();
}
//,supervisor d    AND c.s_id=d.s_id AND d.s_id=$sup";
echo json_encode($rows);