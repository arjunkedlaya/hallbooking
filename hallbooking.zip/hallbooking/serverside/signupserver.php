<?php
session_start();
if(isset($_POST['submit']))
{
    include_once 'databaseconnect.php';
    $name=mysqli_real_escape_string($conn,$_POST['username']);
    $did=mysqli_real_escape_string($conn,$_POST['department']);
    $email=mysqli_real_escape_string($conn,$_POST['email']);
    $pwd=mysqli_real_escape_string($conn,$_POST['pwd']);
    $desig=mysqli_real_escape_string($conn,$_POST['desig']);
   
    //Error Handlers
    if(!preg_match("/^[a-zA-Z ]*$/", $name)){
         header("Location: ../signup.php?signup=InvalidName");
	     exit();
    }
    else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
         header("Location: ../signup.php?signup=InvalidEmail");
	     exit();
    }
    else if(1==1){
    	$sql="SELECT * FROM employee WHERE email='$email'";
    	$result=mysqli_query($conn,$sql);
    	$resultCheck=mysqli_num_rows($result);
    	if($resultCheck>0){
    		header("Location: ../signup.php?emailreigsteredalready");
    		exit();
    	}
    }
   
    $hashpwd=password_hash($pwd, PASSWORD_DEFAULT);
    $sql="INSERT INTO employee (ename, email, pwd, d_id,desig) VALUES ('$name', '$email', '$hashpwd', '$did','$desig');";
    mysqli_query($conn, $sql);
    header("Location: ../signup.php?signup=Success");
    exit();
}
else
{
	header("Location: ../signup.php?signup=fail");
	exit();
}