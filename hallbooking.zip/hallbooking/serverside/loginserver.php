<?php
session_start();
if(isset($_POST['submit']))
{   
    include_once 'databaseconnect.php';
    $email=mysqli_real_escape_string($conn,$_POST['email']);
    $pwd=mysqli_real_escape_string($conn,$_POST['pwd']);
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
     	header("Location:../login.php?login=InvalidEmail");
     	exit();
    }
    $sql="SELECT * FROM supervisor WHERE supemail ='$email'";
    $result=mysqli_query($conn,$sql);
    $resultCheck=mysqli_num_rows($result);
    if($resultCheck>0){
        $sql="SELECT * FROM supervisor WHERE supemail ='$email'";
        $result=mysqli_query($conn,$sql);
        $resultCheck=mysqli_num_rows($result);
        if($resultCheck<1){
            header("Location: ../login.php?login=IncorrectCredentialsSuper");
           exit();
        }
        else if($row=mysqli_fetch_assoc($result)){
            if($pwd!=$row['supwd']){
                 header("Location:../login.php?login=IncorrectCredentialsSuper");
                 exit();
             }
         else if($pwd==$row['supwd']){
                $_SESSION['email']=$row['supemail'];
                header("Location:../dean.php");
                exit();
            }
        }
    }
    else{
    	$sql="SELECT * FROM employee WHERE email ='$email'";
    	$result=mysqli_query($conn,$sql);
    	$resultCheck=mysqli_num_rows($result);
    	if($resultCheck<1){
	        header("Location:../login.php?login=IncorrectCredentials");
	       exit();
    	}
    	else if($row=mysqli_fetch_assoc($result)){
    		$hashedPwdCheck=password_verify($pwd,$row['pwd']);
    		if($hashedPwdCheck==false){
    			 header("Location:../login.php?login=IncorrectCredentials");
	             exit();
	         }
	        else if($hashedPwdCheck==true){
	            $_SESSION['email']=$row['email'];
                header("Location:../home.php");
                exit();
	        }
        }
    	
    }
}
else
{
	header("Location: ../login.php");
	exit();
}