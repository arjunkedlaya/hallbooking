<?php
 session_start();
 if(!isset($_SESSION['email'])){
   header('location:login.php?sessionfailed');
}
 include_once 'databaseconnect.php';
 $sql="SELECT a.r_id,a.hall,a.ftime,a.ttime,a.description,a.date,a.cancelreq,a.eventname,a.status,a.target,b.ename,b.desig,c.dname FROM request a,employee b,department c WHERE a.e_id=b.e_id AND b.d_id=c.d_id";
 $result=mysqli_query($conn,$sql);
 if (mysqli_num_rows($result) > 0) {
    // output data of each row
    $rows = array();
    while($row = mysqli_fetch_assoc($result)) {
        // echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
        $rows[] = $row;
    }
}
echo json_encode($rows);